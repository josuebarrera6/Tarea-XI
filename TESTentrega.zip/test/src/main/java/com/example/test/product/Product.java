package com.example.test.product;

import java.time.LocalDate;

public class Product {
    private long id;
    private String name;
    private Float precio;



    public Product(long id) {
        this.id = id;
    }

    public Product(long id, String name, int precio, LocalDate fecha, int antiguedad) {
        this.id = id;
        this.name = name;
        this.precio = (float) precio;


    }

    public Product(String name, Float precio, LocalDate fecha, int antiguedad) {
        this.name = name;
        this.precio = precio;


    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }




}
