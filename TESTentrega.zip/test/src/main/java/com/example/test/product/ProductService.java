package com.example.test.product;

import org.springframework.stereotype.@Service;

@Service
public class ProductService {
}
